if (import.meta.main) {
  console.log("you ran an essentially empty script.");
}
